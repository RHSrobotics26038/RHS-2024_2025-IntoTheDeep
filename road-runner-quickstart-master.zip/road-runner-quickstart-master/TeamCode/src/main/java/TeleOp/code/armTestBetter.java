package TeleOp.code;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

/*
 * This OpMode executes a POV Game style Teleop for a direct drive robot
 * The code is structured as a LinearOpMode
 *
 * In this mode the left stick moves the robot FWD and back, the Right stick turns left and right.
 * It raises and lowers the arm using the Gamepad Y and A buttons respectively.
 * It also opens and closes the claws slowly using the left and right Bumper buttons.
 *
 * Use Android Studio to Copy this Class, and Paste it into your team's code folder with a new name.
 * Remove or comment out the @Disabled line to add this OpMode to the Driver Station OpMode list
 */

@TeleOp(name="Maddie, Select this one", group="Robot")
@Disabled
public class armTestBetter extends LinearOpMode {

    /* Declare OpMode members. */
    // Declare OpMode members for each of the 4 motors.
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor leftFrontDrive = null;
    private DcMotor leftBackDrive = null;
    private DcMotor rightFrontDrive = null;
    private DcMotor rightBackDrive = null;
    public DcMotor  shoulderMotor = null;
    public DcMotor  slideMotor = null;
    public DcMotor liftMotor1 = null;
    public DcMotor liftMotor2 = null;
    public Servo    claw    = null;


    double clawOffset = 0;

    public static final double MID_SERVO   =  0.0 ;

    public static final double CLAW_SPEED  = 0.05 ;                 // sets rate to move servo
    public static final double ARM_UP_POWER    =  1.0 ;
    public static final double ARM_DOWN_POWER  = -0.8 ;
    public static final double SLIDE_OUT_POWER  =  -0.60 ;
    public static final double SLIDE_IN_POWER  = 0.60 ;

    @Override
    public void runOpMode() {

        // Define and Initialize Motors

        // Initialize the hardware variables. Note that the strings used here must correspond
        // to the names assigned during the robot configuration step on the DS or RC devices.
        leftFrontDrive  = hardwareMap.get(DcMotor.class, "leftFront");
        leftBackDrive  = hardwareMap.get(DcMotor.class, "leftBack");
        rightFrontDrive = hardwareMap.get(DcMotor.class, "rightFront");
        rightBackDrive = hardwareMap.get(DcMotor.class, "rightBack");

        shoulderMotor = hardwareMap.get(DcMotor.class, "shoulderMotor");
        slideMotor = hardwareMap.get(DcMotor.class, "slideMotor");
        liftMotor1 = hardwareMap.get(DcMotor.class, "liftMotor1");
        liftMotor2 = hardwareMap.get(DcMotor.class, "liftMotor2");

        // ########################################################################################
        // !!!            IMPORTANT Drive Information. Test your motor directions.            !!!!!
        // ########################################################################################
        // Most robots need the motors on one side to be reversed to drive forward.
        // The motor reversals shown here are for a "direct drive" robot (the wheels turn the same direction as the motor shaft)
        // If your robot has additional gear reductions or uses a right-angled drive, it's important to ensure
        // that your motors are turning in the correct direction.  So, start out with the reversals here, BUT
        // when you first test your robot, push the left joystick forward and observe the direction the wheels turn.
        // Reverse the direction (flip FORWARD <-> REVERSE ) of any wheel that runs backward
        // Keep testing until ALL the wheels move the robot forward when you push the left joystick forward.
        leftFrontDrive.setDirection(DcMotor.Direction.FORWARD);
        leftBackDrive.setDirection(DcMotor.Direction.FORWARD);
        rightFrontDrive.setDirection(DcMotor.Direction.REVERSE);
        rightBackDrive.setDirection(DcMotor.Direction.REVERSE);
        slideMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        liftMotor1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        liftMotor2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // Define and initialize ALL installed servos.
        claw  = hardwareMap.get(Servo.class, "claw");

        claw.setPosition(MID_SERVO);
        slideMotor.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        slideMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Wait for the game to start (driver presses START)
        telemetry.addData("Status", "Initialized");
        telemetry.update();
        // Send telemetry message to signify robot waiting;
        telemetry.addData(">", "Robot Ready.  Press START.");    //
        telemetry.update();

        // Wait for the game to start (driver presses START)
        waitForStart();
        runtime.reset();
        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            double max;
            // POV Mode uses left joystick to go forward & strafe, and right joystick to rotate.
            double axial   = -gamepad1.left_stick_y;  // Note: pushing stick forward gives negative value
            double lateral =  gamepad1.left_stick_x;
            double yaw     =  gamepad1.right_stick_x;

            // Combine the joystick requests for each axis-motion to determine each wheel's power.
            // Set up a variable for each drive wheel to save the power level for telemetry.
            double leftFrontPower  = axial + lateral + yaw;
            double rightFrontPower = axial - lateral - yaw;
            double leftBackPower   = axial - lateral + yaw;
            double rightBackPower  = axial + lateral - yaw;

            // Normalize the values so no wheel power exceeds 100%
            // This ensures that the robot maintains the desired motion.
            max = Math.max(Math.abs(leftFrontPower), Math.abs(rightFrontPower));
            max = Math.max(max, Math.abs(leftBackPower));
            max = Math.max(max, Math.abs(rightBackPower));

            if (max > 1.0) {
                leftFrontPower /= max;
                rightFrontPower /= max;
                leftBackPower /= max;
                rightBackPower /= max;
            }

            // Use gamepad left & right Bumpers to open and close the claw
//            if (gamepad2.right_bumper)
//                clawOffset += CLAW_SPEED;
//            else if (gamepad2.left_bumper)
//                clawOffset -= CLAW_SPEED;
            if(gamepad2.right_bumper) {claw.setPosition(0);

            } else if (gamepad2.left_bumper) {claw.setPosition(0.3);}


            // Move both servos to new position.  Assume servos are mirror image of each other.
//            clawOffset = Range.clip(clawOffset, -0.5, 0.5);
//            claw.setPosition(MID_SERVO + clawOffset);

//          linier slide
            
            if (gamepad2.dpad_down)
            {slideMotor.setTargetPosition(0);
                slideMotor.setPower(0.6);
                slideMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);}

            if (gamepad2.dpad_up)
            {slideMotor.setTargetPosition(-3090);
                slideMotor.setPower(0.6);
                slideMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);}

            if (gamepad2.dpad_right)
            {slideMotor.setTargetPosition(-2000);
                slideMotor.setPower(0.6);
                slideMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);}

            // Use gamepad buttons to hang arms up (Y) and down (A)

            if (gamepad1.y)
                liftMotor1.setPower(2);
            else if (gamepad1.a)
                liftMotor1.setPower(-2);
            else
                liftMotor1.setPower(0.0);

            if (gamepad1.y)
                liftMotor2.setPower(2);
            else if (gamepad1.a)
                liftMotor2.setPower(-2);
            else
                liftMotor2.setPower(0.0);

            // Use gamepad buttons to move arm up (Y) and down (A)

            if (gamepad2.y)
                shoulderMotor.setPower(ARM_UP_POWER);
            else if (gamepad2.a)
                shoulderMotor.setPower(ARM_DOWN_POWER);
            else
                shoulderMotor.setPower(0.0);

            // Send telemetry message to signify robot running;
//            telemetry.addData("claw",  "Offset = %.2f", clawOffset);
            telemetry.update();

            // Send calculated power to wheels
            leftFrontDrive.setPower(leftFrontPower);
            rightFrontDrive.setPower(rightFrontPower);
            leftBackDrive.setPower(leftBackPower);
            rightBackDrive.setPower(rightBackPower);

            // Show the elapsed game time and wheel power.
            telemetry.addData("Status", "Run Time: " + runtime.toString());
            telemetry.addData("Front left/Right", "%4.2f, %4.2f", leftFrontPower, rightFrontPower);
            telemetry.addData("Back  left/Right", "%4.2f, %4.2f", leftBackPower, rightBackPower);
            telemetry.addData("Slide encoder", "slideMotor" + slideMotor.getCurrentPosition());
            telemetry.addData("claw", "claw" + claw.getPosition());
            telemetry.update();
            // Pace this loop so jaw action is reasonable speed.
            sleep(50);
        }
    }}

