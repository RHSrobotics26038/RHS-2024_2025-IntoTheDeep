package TeleOp.code;

import com.qualcomm.robotcore.hardware.HardwareMap;

public class Motor {
    public Motor(HardwareMap hardwareMap, String rightFront, Object p2) {
    }
}
