package org.firstinspires.ftc.teamcode;

import com.arcrobotics.ftclib.geometry.Pose2d;
import com.arcrobotics.ftclib.geometry.Rotation2d;
import com.arcrobotics.ftclib.geometry.Translation2d;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.teamcode.tuning.ApriltagDatapoint;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@TeleOp(name="Apriltag that Anthony couldn't draw", group="Robot")
public class Apriltag extends LinearOpMode {
        private Limelight limelight;

        @Override
        public void runOpMode() throws InterruptedException
        {
            List<ApriltagDatapoint> apriltags = Arrays.asList(new ApriltagDatapoint(
                    new Pose2d(new Translation2d(0, 0), new Rotation2d(0)),
                    1
            ),new ApriltagDatapoint(
                    new Pose2d(new Translation2d(5, 5), new Rotation2d(0)),
                    2
            ));
            limelight = new Limelight(hardwareMap, apriltags, telemetry);
            waitForStart();

            while (opModeIsActive()) {
                limelight.periodic();
                telemetry.addData("PosX", limelight.currentPosition.getX());
                telemetry.addData("PosY", limelight.currentPosition.getY());
                telemetry.update();
            }
        }
}