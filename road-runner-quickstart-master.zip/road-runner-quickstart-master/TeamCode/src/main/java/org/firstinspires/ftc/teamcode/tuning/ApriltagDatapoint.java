package org.firstinspires.ftc.teamcode.tuning;

import com.arcrobotics.ftclib.geometry.Pose2d;

public class ApriltagDatapoint {
    public Pose2d pose;
    public Integer ID;
    public ApriltagDatapoint (Pose2d pose, Integer ID){
        this.pose = pose;
        this.ID = ID;
    }
    public Pose2d getPose(){
        return pose;
    }
    public Integer getID(){
        return ID;
    }
}
