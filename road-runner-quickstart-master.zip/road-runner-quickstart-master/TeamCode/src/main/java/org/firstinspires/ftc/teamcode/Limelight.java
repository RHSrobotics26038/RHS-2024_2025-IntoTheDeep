package org.firstinspires.ftc.teamcode;

import com.arcrobotics.ftclib.command.SubsystemBase;
import com.arcrobotics.ftclib.geometry.Pose2d;
import com.arcrobotics.ftclib.geometry.Rotation2d;
import com.arcrobotics.ftclib.geometry.Translation2d;
import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;
import org.firstinspires.ftc.teamcode.tuning.ApriltagDatapoint;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Limelight extends SubsystemBase {
    /**
     * Creates a new Subsystem.
     */
    public Limelight3A limelight;
    public Telemetry telemetry;
    public Pose2d currentPosition = null; // new Pose2d(new Translation2d(0, 0), new Rotation2d(0))
    public Map<Integer, ApriltagDatapoint> apriltags = new HashMap<>();
    public Limelight(HardwareMap hardwareMap, List<ApriltagDatapoint> apriltags, Telemetry telemetry) {
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        telemetry.setMsTransmissionInterval(11);
        limelight.pipelineSwitch(0);
        limelight.start();
        this.telemetry = telemetry;
        for (ApriltagDatapoint obj : apriltags) {
            this.apriltags.put(obj.getID(), obj);
        }
    }

    public Pose2d getPose() {
        return currentPosition;
    }

    public static double calculateAverage(List<Double> numbers) {
        if (numbers == null || numbers.isEmpty()) {
            // Or throw an IllegalArgumentException
            return 0.0;
        }

        double sum = 0.0;
        for (double number : numbers) {
            sum += number;
        }

        return sum / numbers.size();
    }

    @Override
    public void periodic() {
        // This method will be called once per scheduler run
        List<Double> Xs = new ArrayList<>();
        List<Double> Ys = new ArrayList<>();
        List<Double> Thetas = new ArrayList<>();
        List<LLResultTypes.FiducialResult> results = limelight.getLatestResult().getFiducialResults();
        for (LLResultTypes.FiducialResult result : results) {
            Pose3D tagPose = result.getRobotPoseFieldSpace();
            double Xm = tagPose.getPosition().x; // X Measured
            double Ym = tagPose.getPosition().z; // Y Measured
            double Thetam = tagPose.getOrientation().getYaw(); // Yaw Measured
            Xs.add(Xm);
            Ys.add(Ym);
            Thetas.add(Thetam);
        }
        currentPosition = new Pose2d(
                new Translation2d(calculateAverage(Xs), calculateAverage(Ys)),
                new Rotation2d(calculateAverage(Thetas))
        );
        telemetry.addData("ResultXm", Xs);
        telemetry.addData("ResultYm", Ys);
        telemetry.addData("ResultThetam", Thetas);
    }
}