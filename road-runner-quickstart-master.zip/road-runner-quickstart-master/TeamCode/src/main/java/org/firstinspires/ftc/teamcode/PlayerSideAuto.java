package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.config.Config;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.TrajectoryActionBuilder;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import java.util.ArrayList;

@Config
@Autonomous(name = "Player Side Auto", group = "Autonomous")
public class PlayerSideAuto extends LinearOpMode {
    public class Slide {
        private DcMotorEx slide;

        public Slide(HardwareMap hardwareMap) {
            slide = hardwareMap.get(DcMotorEx.class, "slideMotor");
            slide.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            slide.setDirection(DcMotorSimple.Direction.REVERSE);
            slide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            slide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        }

        public class SlideUp implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    slide.setPower(0.8);
                    initialized = true;
                }

                double pos = slide.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos < 1800.0) {
                    return true;
                } else {
                    slide.setPower(0);
                    return false;
                }
            }
        }
        public Action slideUp() {
            return new SlideUp();
        }

        public class SlideUp2 implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    slide.setPower(0.8);
                    initialized = true;
                }

                double pos = slide.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos < 2020.0) {
                    return true;
                } else {
                    slide.setPower(0);
                    return false;
                }
            }
        }
        public Action slideUp2() {
            return new SlideUp2();
        }

        public class SlideUp3 implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    slide.setPower(0.53);
                    initialized = true;
                }

                double pos = slide.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos < 2450.0) {
                    return true;
                } else {
                    slide.setPower(0);
                    return false;
                }
            }
        }
        public Action slideUp3() {
            return new SlideUp3();
        }

        public class SlideDown implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    slide.setPower(-0.85);
                    initialized = true;
                }

                double pos = slide.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos > 40.0) {
                    return true;
                } else {
                    slide.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
                    slide.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
                    slide.setPower(0);
                    return false;
                }
            }
        }
        public Action slideDown() {
            return new SlideDown();
        }

        public class SlideDown2 implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    slide.setPower(-0.7);
                    initialized = true;
                }

                double pos = slide.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos > 200.0) {
                    return true;
                } else {
                    slide.setPower(0);
                    return false;
                }
            }
        }
        public Action slideDown2() {
            return new SlideDown2();
        }

    }

    public class Shoulder {
        private DcMotorEx shoulder;

        public Shoulder(HardwareMap hardwareMap) {
            shoulder = hardwareMap.get(DcMotorEx.class, "shoulderMotor");
            shoulder.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            shoulder.setDirection(DcMotorSimple.Direction.FORWARD);
            shoulder.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
            shoulder.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        }

        public class ShoulderUp implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    shoulder.setPower(0.85);
                    initialized = true;
                }

                double pos = shoulder.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos < 1010.0) {
                    return true;
                } else {
                    shoulder.setPower(0);
                    return false;
                }
            }
        }
        public Action shoulderUp() {
            return new ShoulderUp();
        }

        public class ShoulderUp2 implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    shoulder.setPower(0.9);
                    initialized = true;
                }

                double pos = shoulder.getCurrentPosition();
                packet.put("liftPos", pos);
                if (pos < 1490.0) {
                    return true;
                } else {
                    shoulder.setPower(0);
                    return false;
                }
            }
        }
        public Action shoulderUp2() {
            return new ShoulderUp2();
        }

        public class ShoulderDown implements Action {
            private boolean initialized = false;

            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                if (!initialized) {
                    shoulder.setPower(-0.7);
                    initialized = true;
                }

                double pos = shoulder.getCurrentPosition();
                packet.put("shoulderPos", pos);
                if (pos > -193.0) {
                    return true;
                } else {
                    shoulder.setPower(0);
                    return false;
                }
            }
        }
        public Action shoulderDown(){
            return new ShoulderDown();
        }
    }

    public class Claw {
        private Servo claw;

        public Claw(HardwareMap hardwareMap) {
            claw = hardwareMap.get(Servo.class, "claw");
        }

        public class CloseClaw implements Action {
            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                claw.setPosition(0.0);
                return false;
            }
        }
        public Action closeClaw() {
            return new CloseClaw();
        }

        public class OpenClaw implements Action {
            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                claw.setPosition(0.3);
                return false;
            }
        }
        public Action openClaw() {
            return new OpenClaw();
        }

        public class GrabClaw implements Action {
            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                claw.setPosition(-0.12);
                return false;
            }
        }
        public Action grabClaw() {
            return new GrabClaw();
        }
    }

    public class Flag {
        private Servo flag;

        public Flag(HardwareMap hardwareMap) { flag = hardwareMap.get(Servo.class, "flag"); }
        public class FlagUp implements Action {
            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                flag.setPosition(0.1);
                return false;
            }
        }
        public Action flagUp() { return new FlagUp(); }

        public class FlagDown implements Action {
            @Override
            public boolean run(@NonNull TelemetryPacket packet) {
                flag.setPosition(0.55);
                return false;
            }
        }

        public Action flagDown() { return new FlagDown(); }
    }

    @Override
    public void runOpMode() {
        Pose2d initialPose = new Pose2d(9, -72, Math.toRadians(90));
        Pose2d secondPose = new Pose2d(9, -46, Math.toRadians(90));
        Pose2d thirdPose = new Pose2d(57, -56, Math.toRadians(0));
        Pose2d fourthPose = new Pose2d(20, -65, Math.toRadians(-10));
        Pose2d fifthPose = new Pose2d(24, -67.8, Math.toRadians(100));
        Pose2d sixthPose = new Pose2d(-10, -50, Math.toRadians(75));
        MecanumDrive drive = new MecanumDrive(hardwareMap, initialPose, new Limelight(hardwareMap, new ArrayList<>(), telemetry));
        Claw claw = new Claw(hardwareMap);
        Slide slide = new Slide(hardwareMap);
        Shoulder shoulder = new Shoulder(hardwareMap);
        Flag flag = new Flag(hardwareMap);

        // vision here that outputs position
        int visionOutputPosition = 1;

        TrajectoryActionBuilder tab1 = drive.actionBuilder(initialPose)
                .lineToY(-46)
//                slideMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
//                slideMotor.setPower(0.6);
//                .lineToYSplineHeading(-24, Math.toRadians(180))
//                .waitSeconds(2)
//                .setTangent(Math.toRadians(90))
//                .lineToY(48)
//                .setTangent(Math.toRadians(0))
//                .lineToX(32)
//                .strafeTo(new Vector2d(44.5, 30))
//                .turn(Math.toRadians(180))
//                .lineToX(47.5)
                .waitSeconds(0.3);
        TrajectoryActionBuilder tab2 = drive.actionBuilder(secondPose)
                .setTangent(Math.toRadians(0))
                .lineToX(38)
//                .lineToYSplineHeading(-74, Math.toRadians(180))
//                .setTangent(-72)
//                .splineToConstantHeading(new Vector2d(-45, -42), Math.PI / 2)
                .waitSeconds(0.08)
                .lineToY(-23)
                .setTangent(Math.toRadians(0))
                .lineToX(45)
                .waitSeconds(0.08)
                .lineToY(-64)
                .lineToY(-23)
                .setTangent(Math.toRadians(0))
                .lineToX(57)
                .waitSeconds(0.01)
                .lineToY(-64)
                .waitSeconds(0.002)
                .lineToY(-56);


        TrajectoryActionBuilder tab3 = drive.actionBuilder(thirdPose)
                .waitSeconds(0.002)
                .splineToSplineHeading(new Pose2d(20, -65, 0), Math.PI / -2)
                .waitSeconds(0.01);
        TrajectoryActionBuilder tab4 = drive.actionBuilder(fourthPose)
                .strafeTo(new Vector2d( 24, -67.98))
                .waitSeconds(0.5);
        TrajectoryActionBuilder tab5 = drive.actionBuilder(fifthPose)
                .strafeTo(new Vector2d(-10, -50))
                .waitSeconds(0.01);
        TrajectoryActionBuilder waitSeconds = drive.actionBuilder(fifthPose)
                .waitSeconds(1);
        TrajectoryActionBuilder tab6 = drive.actionBuilder(sixthPose)
                .strafeTo(new Vector2d(60, -65))
                .waitSeconds(0.1);
        Action trajectoryActionCloseOut = tab1.fresh()
//                .strafeTo(new Vector2d(48, 12))
                .build();

        // actions that need to happen on init; for instance, a claw tightening.
        Actions.runBlocking(claw.closeClaw());
        Actions.runBlocking(flag.flagDown());

        while (!isStopRequested() && !opModeIsActive()) {
            int position = visionOutputPosition;
            telemetry.addData("Position during Init", position);
            telemetry.update();
        }

        int startPosition = visionOutputPosition;
        telemetry.addData("Starting Position", startPosition);
        telemetry.update();
        waitForStart();

        if (isStopRequested()) return;

        Action trajectoryActionChosen;
        if (startPosition == 1) {
            trajectoryActionChosen = tab1.build();
        } else if (startPosition == 2) {
            trajectoryActionChosen = tab2.build();
        } else {
            trajectoryActionChosen = tab3.build();
        }
        Action trajectoryActionChosen2;{
            trajectoryActionChosen2 = tab2.build();
        }
        Action trajectoryActionChosen3;{
            trajectoryActionChosen3 = tab3.build();
        }
        Action trajectoryActionChosen4;{
            trajectoryActionChosen4 = tab4.build();
        }
        Action trajectoryActionChosen5;{
            trajectoryActionChosen5 = tab5.build();
        }
        Action trajectoryActionChosen6;{
            trajectoryActionChosen6 = waitSeconds.build();
        }
        Action trajectoryActionChosen7;{
            trajectoryActionChosen7 = tab6.build();
        }
        Actions.runBlocking(
                new SequentialAction(
                        new ParallelAction(
                        flag.flagUp(),
                        trajectoryActionChosen,
                            new SequentialAction(
                                shoulder.shoulderUp(),
                                slide.slideUp(),
                                slide.slideDown(),
                                claw.openClaw()
                            )
                        ),
                        new ParallelAction(
                            trajectoryActionChosen2,
                            shoulder.shoulderDown()
                                ),
                        trajectoryActionChosen3,
                        slide.slideUp2(),
                        trajectoryActionChosen4,
                        claw.grabClaw(),
                        trajectoryActionChosen6,
                        new ParallelAction(
                                slide.slideDown(),
                                trajectoryActionChosen5
                                ),
                        new ParallelAction(
                                shoulder.shoulderUp2(),
                                slide.slideUp3()
                                ),
                        claw.openClaw(),
                        trajectoryActionChosen6,
                        new ParallelAction(
                                slide.slideDown(),
                                trajectoryActionChosen7
                                ),
                        trajectoryActionCloseOut

                )
        );
    }
}