Before issuing a pull request, please see the contributing page.

                if (gamepad2.y)
        shoulderMotor.setPower(ARM_UP_POWER);
                else if (gamepad1.a)
        shoulderMotor.setPower(ARM_DOWN_POWER);
                else
                        shoulderMotor.setPower(0.0);